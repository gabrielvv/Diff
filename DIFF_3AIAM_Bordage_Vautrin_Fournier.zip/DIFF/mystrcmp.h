#ifndef MY_STRCMP_INCLUDED
#define MY_STRCMP_INCLUDED

int compare(char*,char*);
int compareString(char *lineA,char *lineB,char *param);

#endif //MY_STRCMP_INCLUDED
